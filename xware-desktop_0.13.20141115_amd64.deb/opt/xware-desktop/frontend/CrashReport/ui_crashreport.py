# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'src/frontend/ui/crashreport.ui'
#
# Created: Thu Apr 21 12:18:33 2016
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(550, 425)
        Dialog.setMinimumSize(QtCore.QSize(550, 425))
        Dialog.setLocale(QtCore.QLocale(QtCore.QLocale.Chinese, QtCore.QLocale.China))
        self.formLayout = QtWidgets.QFormLayout(Dialog)
        self.formLayout.setObjectName("formLayout")
        self.label_summary = QtWidgets.QLabel(Dialog)
        self.label_summary.setObjectName("label_summary")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.label_summary)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem = QtWidgets.QSpacerItem(40, 22, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButton_github = QtWidgets.QPushButton(Dialog)
        self.pushButton_github.setObjectName("pushButton_github")
        self.horizontalLayout.addWidget(self.pushButton_github)
        self.pushButton_close = QtWidgets.QPushButton(Dialog)
        self.pushButton_close.setObjectName("pushButton_close")
        self.horizontalLayout.addWidget(self.pushButton_close)
        self.formLayout.setLayout(2, QtWidgets.QFormLayout.SpanningRole, self.horizontalLayout)
        self.textBrowser = QtWidgets.QTextBrowser(Dialog)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.textBrowser.sizePolicy().hasHeightForWidth())
        self.textBrowser.setSizePolicy(sizePolicy)
        self.textBrowser.setObjectName("textBrowser")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.SpanningRole, self.textBrowser)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Xware Desktop 上演了一出悲剧"))
        self.label_summary.setText(_translate("Dialog", "Xware Desktop运行时出现了错误。请复制以下内容报告给开发者。"))
        self.pushButton_github.setText(_translate("Dialog", "到 Github 提交"))
        self.pushButton_close.setText(_translate("Dialog", "关闭"))

