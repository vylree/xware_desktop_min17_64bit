# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'src/frontend/ui/scheduler.ui'
#
# Created: Thu Apr 21 12:18:32 2016
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SchedulerDialog(object):
    def setupUi(self, SchedulerDialog):
        SchedulerDialog.setObjectName("SchedulerDialog")
        SchedulerDialog.setWindowModality(QtCore.Qt.WindowModal)
        SchedulerDialog.resize(400, 310)
        SchedulerDialog.setMinimumSize(QtCore.QSize(400, 310))
        icon = QtGui.QIcon.fromTheme("xware-desktop")
        SchedulerDialog.setWindowIcon(icon)
        SchedulerDialog.setLocale(QtCore.QLocale(QtCore.QLocale.Chinese, QtCore.QLocale.China))
        self.formLayout = QtWidgets.QFormLayout(SchedulerDialog)
        self.formLayout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self.formLayout.setObjectName("formLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label = QtWidgets.QLabel(SchedulerDialog)
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.comboBox_actWhen = QtWidgets.QComboBox(SchedulerDialog)
        self.comboBox_actWhen.setObjectName("comboBox_actWhen")
        self.horizontalLayout_2.addWidget(self.comboBox_actWhen)
        self.label_4 = QtWidgets.QLabel(SchedulerDialog)
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_2.addWidget(self.label_4)
        self.formLayout.setLayout(0, QtWidgets.QFormLayout.LabelRole, self.horizontalLayout_2)
        self.listView_runningTasks = QtWidgets.QListView(SchedulerDialog)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.listView_runningTasks.sizePolicy().hasHeightForWidth())
        self.listView_runningTasks.setSizePolicy(sizePolicy)
        self.listView_runningTasks.setObjectName("listView_runningTasks")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.SpanningRole, self.listView_runningTasks)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_2 = QtWidgets.QLabel(SchedulerDialog)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.comboBox_action = QtWidgets.QComboBox(SchedulerDialog)
        self.comboBox_action.setMinimumSize(QtCore.QSize(80, 0))
        self.comboBox_action.setObjectName("comboBox_action")
        self.horizontalLayout.addWidget(self.comboBox_action)
        self.label_3 = QtWidgets.QLabel(SchedulerDialog)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)
        self.formLayout.setLayout(2, QtWidgets.QFormLayout.LabelRole, self.horizontalLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(SchedulerDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.FieldRole, self.buttonBox)
        self.label.setBuddy(self.comboBox_actWhen)
        self.label_4.setBuddy(self.comboBox_actWhen)
        self.label_2.setBuddy(self.comboBox_action)
        self.label_3.setBuddy(self.comboBox_action)

        self.retranslateUi(SchedulerDialog)
        self.buttonBox.accepted.connect(SchedulerDialog.accept)
        self.buttonBox.rejected.connect(SchedulerDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(SchedulerDialog)

    def retranslateUi(self, SchedulerDialog):
        _translate = QtCore.QCoreApplication.translate
        SchedulerDialog.setWindowTitle(_translate("SchedulerDialog", "计划任务"))
        self.label.setText(_translate("SchedulerDialog", "当"))
        self.label_4.setText(_translate("SchedulerDialog", "任务完成时"))
        self.label_2.setText(_translate("SchedulerDialog", "执行"))
        self.label_3.setText(_translate("SchedulerDialog", "动作"))

import resource_rc
