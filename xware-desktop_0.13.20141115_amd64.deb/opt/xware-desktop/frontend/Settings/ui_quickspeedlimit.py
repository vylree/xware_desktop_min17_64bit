# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'src/frontend/ui/quickspeedlimit.ui'
#
# Created: Thu Apr 21 12:18:32 2016
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form_quickSpeedLimit(object):
    def setupUi(self, Form_quickSpeedLimit):
        Form_quickSpeedLimit.setObjectName("Form_quickSpeedLimit")
        Form_quickSpeedLimit.resize(191, 71)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form_quickSpeedLimit.sizePolicy().hasHeightForWidth())
        Form_quickSpeedLimit.setSizePolicy(sizePolicy)
        Form_quickSpeedLimit.setMinimumSize(QtCore.QSize(191, 71))
        Form_quickSpeedLimit.setMaximumSize(QtCore.QSize(191, 71))
        Form_quickSpeedLimit.setLocale(QtCore.QLocale(QtCore.QLocale.Chinese, QtCore.QLocale.China))
        self.layoutWidget = QtWidgets.QWidget(Form_quickSpeedLimit)
        self.layoutWidget.setGeometry(QtCore.QRect(10, 10, 172, 54))
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.layoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.checkBox_ulSpeedLimit = QtWidgets.QCheckBox(self.layoutWidget)
        self.checkBox_ulSpeedLimit.setObjectName("checkBox_ulSpeedLimit")
        self.gridLayout.addWidget(self.checkBox_ulSpeedLimit, 0, 0, 1, 1)
        self.spinBox_ulSpeedLimit = QtWidgets.QSpinBox(self.layoutWidget)
        self.spinBox_ulSpeedLimit.setMinimum(0)
        self.spinBox_ulSpeedLimit.setMaximum(2048)
        self.spinBox_ulSpeedLimit.setSingleStep(20)
        self.spinBox_ulSpeedLimit.setObjectName("spinBox_ulSpeedLimit")
        self.gridLayout.addWidget(self.spinBox_ulSpeedLimit, 0, 1, 1, 1)
        self.checkBox_dlSpeedLimit = QtWidgets.QCheckBox(self.layoutWidget)
        self.checkBox_dlSpeedLimit.setObjectName("checkBox_dlSpeedLimit")
        self.gridLayout.addWidget(self.checkBox_dlSpeedLimit, 1, 0, 1, 1)
        self.spinBox_dlSpeedLimit = QtWidgets.QSpinBox(self.layoutWidget)
        self.spinBox_dlSpeedLimit.setMinimum(0)
        self.spinBox_dlSpeedLimit.setMaximum(2048)
        self.spinBox_dlSpeedLimit.setSingleStep(50)
        self.spinBox_dlSpeedLimit.setObjectName("spinBox_dlSpeedLimit")
        self.gridLayout.addWidget(self.spinBox_dlSpeedLimit, 1, 1, 1, 1)

        self.retranslateUi(Form_quickSpeedLimit)
        QtCore.QMetaObject.connectSlotsByName(Form_quickSpeedLimit)
        Form_quickSpeedLimit.setTabOrder(self.spinBox_ulSpeedLimit, self.spinBox_dlSpeedLimit)

    def retranslateUi(self, Form_quickSpeedLimit):
        _translate = QtCore.QCoreApplication.translate
        Form_quickSpeedLimit.setWindowTitle(_translate("Form_quickSpeedLimit", "Form"))
        self.checkBox_ulSpeedLimit.setText(_translate("Form_quickSpeedLimit", "上传限速"))
        self.spinBox_ulSpeedLimit.setSuffix(_translate("Form_quickSpeedLimit", " KiB/s"))
        self.checkBox_dlSpeedLimit.setText(_translate("Form_quickSpeedLimit", "下载限速"))
        self.spinBox_dlSpeedLimit.setSuffix(_translate("Form_quickSpeedLimit", " KiB/s"))

